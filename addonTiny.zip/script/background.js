function showDiv() {
		var s = "http://tinyurl.com/api-create.php?url=";
			document.getElementById('second').style.display = "block";
			var value = document.getElementById('URLval');
			var finalstr = s.concat(value);
		}